def addPyFiles_is_successfull():
    return(True)

def sum_two_variables(a, b):
    return(sum([a,b]))
    